<?php $__env->startSection('content'); ?>
    <h1>لوحة التحكم</h1>

    <div class="row mt-4">
        <div class="col-md-3 mb-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">إجمالي الطلبات</h5>
                    <p class="card-text display-4"><?php echo e($totalOrders); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">الطلبات المعلقة</h5>
                    <p class="card-text display-4"><?php echo e($pendingOrders); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">إجمالي المنتجات</h5>
                    <p class="card-text display-4"><?php echo e($totalProducts); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">إجمالي الزبائن</h5>
                    <p class="card-text display-4"><?php echo e($totalClients); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>المنتجات منخفضة المخزون</h5>
                </div>
                <div class="card-body">
                    <?php if($lowStockProducts->count() > 0): ?>
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>المنتج</th>
                                    <th>كمية المخزن</th>
                                    <th>حد التحذير</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($inventory->product->name_en); ?></td>
                                        <td><?php echo e($inventory->stock_quantity); ?></td>
                                        <td><?php echo e($inventory->minimum_alert_quantity); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>لا توجد منتجات منخفضة المخزون.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>الطلبات الأخيرة</h5>
                </div>
                <div class="card-body">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>رقم الطلب</th>
                                <th>الزبون</th>
                                <th>الإجمالي</th>
                                <th>الحالة</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($order->id); ?></td>
                                    <?php if($order->client): ?>
                                        <td><?php echo e($order->client->first_name); ?> <?php echo e($order->client->last_name); ?></td>
                                    <?php else: ?>
                                        <td>عن طريق المدير</td>
                                    <?php endif; ?>

                                    <td>$<?php echo e(number_format($order->total_amount, 2)); ?></td>
                                    <td><span
                                            class="badge bg-info"><?php echo e(\App\Models\Order::STATUSES[$order->status] ?? 'غير معروفة'); ?>

                                        </span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>