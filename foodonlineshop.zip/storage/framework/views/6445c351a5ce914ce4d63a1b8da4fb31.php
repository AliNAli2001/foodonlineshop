<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2><?php echo e($category->name_en); ?> - Category Details</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-secondary">Back</a>
            <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>" class="btn btn-warning">Edit</a>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Category Information</h5>
                </div>
                <div class="card-body">
                    <p><strong>Name (EN):</strong> <?php echo e($category->name_en); ?></p>
                    <p><strong>Name (AR):</strong> <?php echo e($category->name_ar); ?></p>
                    <p><strong>Type:</strong> <span class="badge bg-info"><?php echo e(ucfirst($category->type)); ?></span></p>
                    <p><strong>Featured:</strong> <span class="badge <?php echo e($category->featured ? 'bg-success' : 'bg-secondary'); ?>"><?php echo e($category->featured ? 'Yes' : 'No'); ?></span></p>
                    <?php if($category->category_image): ?>
                        <p><strong>Image:</strong></p>
                        <img src="<?php echo e(asset('storage/' . $category->category_image)); ?>" alt="<?php echo e($category->name_en); ?>" style="max-width: 200px; max-height: 200px;">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-md-8">
                    <h5>Products in This Category (<?php echo e($products->total()); ?>)</h5>
                </div>
                <div class="col-md-4 text-end">
                    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-sm btn-primary">Add Product</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if($products->count() > 0): ?>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Featured</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->name_en); ?></td>
                                <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                                <td><?php echo e($product->inventory->stock_quantity ?? 0); ?></td>
                                <td>
                                    <span class="badge <?php echo e($product->featured ? 'bg-success' : 'bg-secondary'); ?>">
                                        <?php echo e($product->featured ? 'Yes' : 'No'); ?>

                                    </span>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.products.show', $product->id)); ?>" class="btn btn-sm btn-info">View</a>
                                    <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?php echo e(route('admin.products.categories.index', $product->id)); ?>" class="btn btn-sm btn-secondary">Categories</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($products->links()); ?>

            <?php else: ?>
                <p class="text-muted">No products in this category yet</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/categories/show.blade.php ENDPATH**/ ?>