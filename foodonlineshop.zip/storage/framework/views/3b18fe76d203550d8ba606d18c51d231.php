<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Inventory: <?php echo e($product->name_en); ?></h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('admin.inventory.index')); ?>" class="btn btn-secondary">Back</a>
            <a href="<?php echo e(route('admin.inventory.edit', $inventory->id)); ?>" class="btn btn-warning">Edit</a>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Current Inventory</h5>
                </div>
                <div class="card-body">
                    <p><strong>Product:</strong> <?php echo e($product->name_en); ?></p>
                    <p><strong>Stock Quantity:</strong> <?php echo e($inventory->stock_quantity); ?></p>
                    <p><strong>Reserved Quantity:</strong> <?php echo e($inventory->reserved_quantity); ?></p>
                    <p><strong>Available:</strong> <?php echo e($inventory->getAvailableStock()); ?></p>
                    <p><strong>Minimum Alert:</strong> <?php echo e($inventory->minimum_alert_quantity); ?></p>
                    <p><strong>Status:</strong> 
                        <?php if($inventory->isBelowMinimum()): ?>
                            <span class="badge bg-warning">Below Minimum</span>
                        <?php else: ?>
                            <span class="badge bg-success">OK</span>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h5>Recent Transactions</h5>
        </div>
        <div class="card-body">
            <?php if($transactions->count() > 0): ?>
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Quantity Change</th>
                            <th>Reserved Change</th>
                            <th>Reason</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="badge bg-info"><?php echo e(ucfirst($transaction->transaction_type)); ?></span></td>
                                <td><?php echo e($transaction->quantity_change > 0 ? '+' : ''); ?><?php echo e($transaction->quantity_change); ?></td>
                                <td><?php echo e($transaction->reserved_change > 0 ? '+' : ''); ?><?php echo e($transaction->reserved_change); ?></td>
                                <td><?php echo e($transaction->reason); ?></td>
                                <td><?php echo e($transaction->created_at->format('Y-m-d H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($transactions->links()); ?>

            <?php else: ?>
                <p class="text-muted">No transactions yet</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/inventory/show.blade.php ENDPATH**/ ?>