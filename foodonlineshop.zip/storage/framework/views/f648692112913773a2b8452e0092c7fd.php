<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>إدارة التصنيفات للمنتج: <?php echo e($product->name_ar ?? $product->name_en); ?></h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary">الرجوع إلى قائمة المنتجات</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('admin.products.categories.update', $product->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label class="form-label">اختر التصنيفات</label>
                    <div class="border p-3" style="max-height: 400px; overflow-y: auto;">
                        <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input 
                                    class="form-check-input" 
                                    type="checkbox" 
                                    name="categories[]" 
                                    value="<?php echo e($category->id); ?>"
                                    id="category_<?php echo e($category->id); ?>"
                                    <?php echo e(in_array($category->id, $selectedCategoryIds) ? 'checked' : ''); ?>

                                >
                                <label class="form-check-label" for="category_<?php echo e($category->id); ?>">
                                    <?php echo e($category->name_ar); ?> (<?php echo e($category->name_en); ?>)
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">حفظ التصنيفات</button>
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/products/categories/index.blade.php ENDPATH**/ ?>