

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-8">
        <h1>موظف التوصيل: <?php echo e($delivery->full_name); ?></h1>
    </div>
    <div class="col-md-4 text-end">
        <a href="<?php echo e(route('admin.delivery.index')); ?>" class="btn btn-secondary">العودة إلى قائمة موظفي التوصيل</a>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5>تفاصيل التوصيل</h5>
            </div>
            <div class="card-body">
                <p><strong>الهاتف:</strong> <?php echo e($delivery->phone); ?></p>
                <?php if($delivery->phone_plus): ?>
                    <p><strong>هاتف إضافي:</strong> <?php echo e($delivery->phone_plus); ?></p>
                <?php endif; ?>
                <?php if($delivery->email): ?>
                    <p><strong>البريد الإلكتروني:</strong> <?php echo e($delivery->email); ?></p>
                <?php endif; ?>
                <p><strong>الحالة:</strong> <span class="badge bg-info"><?php echo e(ucfirst($delivery->status)); ?></span></p>
                <?php if($delivery->info): ?>
                    <p><strong>معلومات إضافية:</strong> <?php echo e($delivery->info); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <h2>الطلبات المعينة</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>رقم الطلب</th>
                    <th>العميل</th>
                    <th>الإجمالي</th>
                    <th>الحالة</th>
                    <th>التاريخ</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>#<?php echo e($order->id); ?></td>
                        <td>
                            <?php if($order->client_id): ?>
                                <?php echo e($order->client->first_name); ?> <?php echo e($order->client->last_name); ?>

                            <?php else: ?>
                                <span class="badge bg-warning">طلب من المسؤول</span>
                            <?php endif; ?>
                        </td>
                        <td>$<?php echo e(number_format($order->total_amount, 2)); ?></td>
                        <td><span class="badge bg-info"><?php echo e(ucfirst($order->status)); ?></span></td>
                        <td><?php echo e($order->order_date->format('Y-m-d H:i')); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" class="btn btn-sm btn-primary">عرض</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">لا توجد طلبات معينة.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="row mt-4">
            <div class="col-md-12">
                <?php echo e($orders->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/delivery/show.blade.php ENDPATH**/ ?>