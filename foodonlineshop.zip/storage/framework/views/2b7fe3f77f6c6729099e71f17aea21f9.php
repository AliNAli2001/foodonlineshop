<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-6">
        <?php if($product->primaryImage): ?>
            <img src="<?php echo e($product->primaryImage->image_url); ?>" class="img-fluid" alt="<?php echo e($product->name_en); ?>">
        <?php endif; ?>
        <div class="row mt-3">
            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-2">
                    <img src="<?php echo e($image->image_url); ?>" class="img-fluid" alt="<?php echo e($image->caption); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="col-md-6">
        <h1><?php echo e($product->name_en); ?></h1>
        <p class="text-muted"><?php echo e($product->description_en); ?></p>

        <h3 class="mb-3">$<?php echo e(number_format($product->price, 2)); ?></h3>

        <p>
            <?php if($product->isInStock()): ?>
                <span class="badge bg-success">In Stock (<?php echo e($product->getAvailableStock()); ?> available)</span>
            <?php else: ?>
                <span class="badge bg-danger">Out of Stock</span>
            <?php endif; ?>
        </p>

        <?php if($product->categories->count() > 0): ?>
            <p>
                <strong>Categories:</strong>
                <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('categories.show', $category->id)); ?>" class="badge bg-info"><?php echo e($category->name_en); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        <?php endif; ?>

        <?php if($product->isInStock()): ?>
            <form id="addToCartForm" class="mt-4">
                <div class="mb-3">
                    <label for="quantity" class="form-label">Quantity</label>
                    <input type="number" class="form-control" id="quantity" name="quantity" value="1" min="1" required>
                </div>
                <button type="submit" class="btn btn-primary btn-lg">Add to Cart</button>
            </form>
        <?php endif; ?>

        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary mt-3">Back to Products</a>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<script>
    document.getElementById('addToCartForm').addEventListener('submit', function(e) {
        e.preventDefault();

        const quantity = parseInt(document.getElementById('quantity').value);

        fetch('<?php echo e(route("cart.add")); ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({
                product_id: <?php echo e($product->id); ?>,
                quantity: quantity
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Add to localStorage
                const cart = JSON.parse(localStorage.getItem('cart') || '{}');
                const productId = data.product.id.toString();

                if (cart[productId]) {
                    cart[productId].quantity += data.product.quantity;
                } else {
                    cart[productId] = {
                        id: data.product.id,
                        name: data.product.name,
                        price: data.product.price,
                        quantity: data.product.quantity
                    };
                }

                localStorage.setItem('cart', JSON.stringify(cart));
                alert(data.message);
                window.location.href = '<?php echo e(route("cart.index")); ?>';
            } else {
                alert(data.message);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/products/show.blade.php ENDPATH**/ ?>