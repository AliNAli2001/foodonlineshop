<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-12">
        <h1>Order #<?php echo e($order->id); ?></h1>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card mb-3">
            <div class="card-header">
                <h5>Order Information</h5>
            </div>
            <div class="card-body">
                <?php if($order->client_id): ?>
                    <p><strong>Client:</strong> <?php echo e($order->client->first_name); ?> <?php echo e($order->client->last_name); ?></p>
                    <p><strong>Client Phone:</strong> <?php echo e($order->client->phone); ?></p>
                <?php else: ?>
                    <p><strong>Order Type:</strong> <span class="badge bg-warning">Admin Created</span></p>
                    <?php if($order->createdByAdmin): ?>
                        <p><strong>Created By:</strong> <?php echo e($order->createdByAdmin->first_name); ?> <?php echo e($order->createdByAdmin->last_name); ?></p>
                    <?php endif; ?>
                <?php endif; ?>
                <p><strong>Status:</strong> <span class="badge bg-info"><?php echo e(ucfirst($order->status)); ?></span></p>
                <p><strong>Order Date:</strong> <?php echo e($order->order_date->format('Y-m-d H:i')); ?></p>
                <p><strong>Order Source:</strong> <?php echo e(ucfirst(str_replace('_', ' ', $order->order_source))); ?></p>
                <p><strong>Delivery Method:</strong> <?php echo e(ucfirst(str_replace('_', ' ', $order->delivery_method))); ?></p>
                <p><strong>Address:</strong> <?php echo e($order->address_details); ?></p>
                <?php if($order->latitude && $order->longitude): ?>
                    <p><strong>Location:</strong> <?php echo e($order->latitude); ?>, <?php echo e($order->longitude); ?></p>
                <?php endif; ?>
                <?php if($order->shipping_notes): ?>
                    <p><strong>Shipping Notes:</strong> <?php echo e($order->shipping_notes); ?></p>
                <?php endif; ?>
                <?php if($order->admin_order_client_notes): ?>
                    <p><strong>Admin Notes:</strong> <?php echo e($order->admin_order_client_notes); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header">
                <h5>Order Items</h5>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Unit Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->product->name_en); ?></td>
                                <td>$<?php echo e(number_format($item->unit_price, 2)); ?></td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td>$<?php echo e(number_format($item->unit_price * $item->quantity, 2)); ?></td>
                                <td>
                                    <span class="badge <?php echo e($item->status === 'normal' ? 'bg-success' : 'bg-warning'); ?>">
                                        <?php echo e(ucfirst($item->status)); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Status Management Section -->
        <div class="card mt-3">
            <div class="card-header">
                <h5>Order Status Management</h5>
            </div>
            <div class="card-body">
                <p class="mb-3"><strong>Current Status:</strong> <span class="badge bg-info"><?php echo e(ucfirst($order->status)); ?></span></p>

                <?php if($order->status === 'pending'): ?>
                    <div class="btn-group" role="group">
                        <form action="<?php echo e(route('admin.orders.confirm', $order->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success">Confirm Order</button>
                        </form>
                        <form action="<?php echo e(route('admin.orders.reject', $order->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Reject Order</button>
                        </form>
                    </div>
                <?php elseif($order->status === 'confirmed'): ?>
                    <div class="btn-group" role="group">
                        <form action="<?php echo e(route('admin.orders.update-status', $order->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="shipped">
                            <button type="submit" class="btn btn-primary">Mark as Shipped</button>
                        </form>
                        <form action="<?php echo e(route('admin.orders.update-status', $order->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="canceled">
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Cancel Order</button>
                        </form>
                    </div>
                <?php elseif($order->status === 'shipped'): ?>
                    <div class="btn-group" role="group">
                        <form action="<?php echo e(route('admin.orders.update-status', $order->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="delivered">
                            <button type="submit" class="btn btn-primary">Mark as Delivered</button>
                        </form>
                        <form action="<?php echo e(route('admin.orders.update-status', $order->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="done">
                            <button type="submit" class="btn btn-success">Mark as Done</button>
                        </form>
                        <form action="<?php echo e(route('admin.orders.update-status', $order->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="canceled">
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Cancel Order</button>
                        </form>
                    </div>
                <?php elseif($order->status === 'delivered'): ?>
                    <div class="btn-group" role="group">
                        <form action="<?php echo e(route('admin.orders.update-status', $order->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="done">
                            <button type="submit" class="btn btn-success">Mark as Done</button>
                        </form>
                        <form action="<?php echo e(route('admin.orders.update-status', $order->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="canceled">
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Cancel Order</button>
                        </form>
                    </div>
                <?php elseif($order->status === 'done' || $order->status === 'canceled'): ?>
                    <p class="text-muted">This order is <?php echo e($order->status); ?>. No further actions available.</p>
                <?php endif; ?>
            </div>
        </div>

        <?php if($order->status === 'confirmed'): ?>
            <div class="card mt-3">
                <div class="card-header">
                    <h5>Delivery Method & Assignment</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.orders.update-delivery-method', $order->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-3">
                            <label for="delivery_method" class="form-label">Delivery Method</label>
                            <select class="form-control" id="delivery_method" name="delivery_method" required onchange="toggleDeliveryFields()">
                                <option value="">-- Select Delivery Method --</option>
                                <option value="delivery" <?php echo e($order->delivery_method === 'delivery' ? 'selected' : ''); ?>>Delivery (Select Delivery Person)</option>
                                <option value="hand_delivered" <?php echo e($order->delivery_method === 'hand_delivered' ? 'selected' : ''); ?>>Hand Delivered (Inside City)</option>
                                <option value="shipping" <?php echo e($order->delivery_method === 'shipping' ? 'selected' : ''); ?>>Shipping (Outside City)</option>
                            </select>
                        </div>

                        <div class="mb-3" id="deliveryPersonField" style="display: <?php echo e($order->delivery_method === 'delivery' ? 'block' : 'none'); ?>;">
                            <label for="delivery_id" class="form-label">Delivery Person</label>
                            <select class="form-control" id="delivery_id" name="delivery_id">
                                <option value="">-- Select Delivery Person --</option>
                                <?php $__currentLoopData = $deliveryPersons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($delivery->id); ?>" <?php echo e($order->delivery_id === $delivery->id ? 'selected' : ''); ?>>
                                        <?php echo e($delivery->first_name); ?> <?php echo e($delivery->last_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="shipping_notes" class="form-label">Shipping Notes (Optional)</label>
                            <textarea class="form-control" id="shipping_notes" name="shipping_notes" rows="3"><?php echo e($order->shipping_notes); ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Update Delivery Method</button>
                    </form>
                </div>
            </div>

            <script>
                function toggleDeliveryFields() {
                    const method = document.getElementById('delivery_method').value;
                    const deliveryField = document.getElementById('deliveryPersonField');
                    const deliverySelect = document.getElementById('delivery_id');

                    if (method === 'delivery') {
                        deliveryField.style.display = 'block';
                        deliverySelect.required = true;
                    } else {
                        deliveryField.style.display = 'none';
                        deliverySelect.required = false;
                    }
                }
            </script>
        <?php endif; ?>

        <?php if($order->delivery_id): ?>
            <div class="card mt-3">
                <div class="card-header">
                    <h5>Delivery Information</h5>
                </div>
                <div class="card-body">
                    <p><strong>Delivery Person:</strong> <?php echo e($order->delivery->first_name); ?> <?php echo e($order->delivery->last_name); ?></p>
                    <p><strong>Phone:</strong> <?php echo e($order->delivery->phone); ?></p>
                    <p><strong>Status:</strong> <?php echo e(ucfirst($order->delivery->status)); ?></p>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Order Summary</h5>
                <p>Total: $<?php echo e(number_format($order->total_amount, 2)); ?></p>
                <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-secondary w-100">Back to Orders</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>