<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-12">
        <h1>Welcome to Food Online Shop</h1>
        <p>Browse our delicious products and place your order today!</p>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <h3>Featured Categories</h3>
    </div>
</div>

<div class="row mb-4">
    <?php $__empty_1 = true; $__currentLoopData = $featuredCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-3 mb-3">
            <div class="card">
                <?php if($category->image): ?>
                    <img src="<?php echo e($category->image->image_url); ?>" class="card-img-top" alt="<?php echo e($category->name_en); ?>">
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($category->name_en); ?></h5>
                    <a href="<?php echo e(route('categories.show', $category->id)); ?>" class="btn btn-sm btn-primary">View</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-md-12">
            <p>No featured categories available.</p>
        </div>
    <?php endif; ?>
</div>

<div class="row mb-4">
    <div class="col-md-12">
        <h3>Featured Products</h3>
    </div>
</div>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-3 mb-3">
            <div class="card product-card">
                <?php if($product->primaryImage): ?>
                    <img src="<?php echo e($product->primaryImage->image_url); ?>" class="card-img-top" alt="<?php echo e($product->name_en); ?>">
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($product->name_en); ?></h5>
                    <p class="card-text">Price: $<?php echo e(number_format($product->price, 2)); ?></p>
                    <p class="card-text">
                        <?php if($product->isInStock()): ?>
                            <span class="badge bg-success">In Stock</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Out of Stock</span>
                        <?php endif; ?>
                    </p>
                    <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-sm btn-primary">View</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-md-12">
            <p>No featured products available.</p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/home.blade.php ENDPATH**/ ?>