<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Damaged Goods Details</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('admin.damaged-goods.index')); ?>" class="btn btn-secondary">Back</a>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h5>Damaged Goods Information</h5>
        </div>
        <div class="card-body">
            <p><strong>Product:</strong> <?php echo e($damagedGoods->product->name_en); ?></p>
            <p><strong>Quantity:</strong> <?php echo e($damagedGoods->quantity); ?></p>
            <p><strong>Source:</strong> <span class="badge bg-info"><?php echo e(ucfirst($damagedGoods->source)); ?></span></p>
            <p><strong>Reason:</strong> <?php echo e($damagedGoods->reason); ?></p>
            <?php if($damagedGoods->returnItem): ?>
                <p><strong>Related Return:</strong> <a href="<?php echo e(route('admin.returns.show', $damagedGoods->returnItem->id)); ?>">Return #<?php echo e($damagedGoods->returnItem->id); ?></a></p>
            <?php endif; ?>
            <?php if($damagedGoods->inventoryTransaction): ?>
                <p><strong>Inventory Transaction:</strong>
                    <span class="badge bg-success"><?php echo e($damagedGoods->inventoryTransaction->transaction_type); ?></span>
                    (ID: <?php echo e($damagedGoods->inventoryTransaction->id); ?>)
                </p>
            <?php endif; ?>
            <p><strong>Date:</strong> <?php echo e($damagedGoods->created_at->format('Y-m-d H:i')); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/damaged-goods/show.blade.php ENDPATH**/ ?>