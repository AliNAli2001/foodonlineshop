<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>تفاصيل البضائع التالفة</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('admin.damaged-goods.index')); ?>" class="btn btn-secondary">العودة</a>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h5>معلومات البضائع التالفة</h5>
        </div>
        <div class="card-body">
            <p><strong>المنتج:</strong> <?php echo e($damagedGoods->product->name_ar); ?></p>
            <p><strong>الكمية:</strong> <?php echo e($damagedGoods->quantity); ?></p>
            <p><strong>المصدر:</strong> <span class="badge bg-info"><?php echo e(ucfirst($damagedGoods->source)); ?></span></p>
            <p><strong>السبب:</strong> <?php echo e($damagedGoods->reason); ?></p>
            <?php if($damagedGoods->returnItem): ?>
                <p><strong>مرتبط بالإرجاع:</strong> <a href="<?php echo e(route('admin.returns.show', $damagedGoods->returnItem->id)); ?>">إرجاع #<?php echo e($damagedGoods->returnItem->id); ?></a></p>
            <?php endif; ?>
            <?php if($damagedGoods->inventoryTransaction): ?>
                <p><strong>حركة المخزون:</strong>
                    <span class="badge bg-success"><?php echo e($damagedGoods->inventoryTransaction->transaction_type); ?></span>
                    (المعرف: <?php echo e($damagedGoods->inventoryTransaction->id); ?>)
                </p>
            <?php endif; ?>
            <p><strong>التاريخ:</strong> <?php echo e($damagedGoods->created_at->format('Y-m-d H:i')); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/damaged-goods/show.blade.php ENDPATH**/ ?>