<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>إدارة البضائع التالفة</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('admin.damaged-goods.create')); ?>" class="btn btn-primary">إضافة بضاعة تالفة</a>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary">العودة</a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>المنتج</th>
                        <th>الكمية</th>
                        <th>المصدر</th>
                        <th>السبب</th>
                        <th>التاريخ</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $damagedGoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $damaged): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($damaged->product->name_ar); ?></td>
                            <td><?php echo e($damaged->quantity); ?></td>
                            <td><span class="badge bg-info"><?php echo e(ucfirst($damaged->source)); ?></span></td>
                            <td><?php echo e($damaged->reason); ?></td>
                            <td><?php echo e($damaged->created_at->format('Y-m-d H:i')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.damaged-goods.show', $damaged->id)); ?>" class="btn btn-sm btn-info">عرض</a>
                                <form action="<?php echo e(route('admin.damaged-goods.destroy', $damaged->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد؟')">حذف</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($damagedGoods->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/damaged-goods/index.blade.php ENDPATH**/ ?>