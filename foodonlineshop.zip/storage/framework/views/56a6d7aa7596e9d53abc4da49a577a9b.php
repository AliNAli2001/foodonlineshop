<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>إدارة المخزون</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary">العودة إلى لوحة التحكم</a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h5 class="mb-0"><?php echo e($product->name_en); ?></h5>
                        <small><?php echo e($product->name_ar); ?></small>
                    </div>
                    <div class="col-md-4 text-end">
                        <span class="badge bg-info">إجمالي المخزون: <?php echo e($product->total_stock); ?></span>
                        <span class="badge bg-success">المتاح: <?php echo e($product->total_available_stock); ?></span>
                        <span class="badge bg-warning">المحجوز: <?php echo e($product->total_reserved_stock); ?></span>
                        <a href="<?php echo e(route('admin.inventory.product', $product->id)); ?>" class="btn btn-sm btn-info"><i class="fa fa-eye"></i> عرض</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if($product->inventories->count() > 0): ?>
                    <table class="table table-sm table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>رقم الدفعة</th>
                                <th>تاريخ الانتهاء</th>
                                <th>سعر التكلفة</th>
                                <th>المخزون</th>
                                <th>المحجوز</th>
                                <th>المتاح</th>
                                <th>تنبيه الحد الأدنى</th>
                                <th>الحالة</th>
                                <th>إجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $product->inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="<?php if($inventory->isExpired()): ?> table-danger <?php elseif($inventory->isExpiringSoon()): ?> table-warning <?php endif; ?>">
                                    <td>
                                        <?php if($inventory->batch_number): ?>
                                            <code><?php echo e($inventory->batch_number); ?></code>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($inventory->expiry_date): ?>
                                            <strong><?php echo e($inventory->expiry_date->format('Y-m-d')); ?></strong>
                                            <?php if($inventory->isExpired()): ?>
                                                <span class="badge bg-danger">منتهي الصلاحية</span>
                                            <?php elseif($inventory->isExpiringSoon()): ?>
                                                <span class="badge bg-warning">ستنتهي قريباً (<?php echo e($inventory->getDaysUntilExpiry()); ?> أيام)</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">لا يوجد تاريخ انتهاء</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($inventory->cost_price); ?></td>
                                    <td><?php echo e($inventory->stock_quantity); ?></td>
                                    <td><?php echo e($inventory->reserved_quantity); ?></td>
                                    <td>
                                        <strong><?php echo e($inventory->getAvailableStock()); ?></strong>
                                    </td>
                                    <td><?php echo e($inventory->minimum_alert_quantity); ?></td>
                                    <td>
                                        <?php if($inventory->isBelowMinimum()): ?>
                                            <span class="badge bg-warning">أقل من الحد الأدنى</span>
                                        <?php elseif($inventory->isExpired()): ?>
                                            <span class="badge bg-danger">منتهي الصلاحية</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">سليم</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.inventory.show', $inventory->id)); ?>" class="btn btn-sm btn-info" title="عرض جميع الدفعات">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="alert alert-info mb-0">
                        لا توجد سجلات مخزون لهذا المنتج.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="d-flex justify-content-center">
        <?php echo e($products->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/inventory/index.blade.php ENDPATH**/ ?>