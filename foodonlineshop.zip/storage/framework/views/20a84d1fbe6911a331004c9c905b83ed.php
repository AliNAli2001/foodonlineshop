<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-12 d-flex justify-content-between align-items-center">
        <h1>المنتجات</h1>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary">إضافة منتج</a>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>رقم المنتج</th>
                    <th>الاسم (بالإنجليزية)</th>
                    <th>السعر</th>
                    <th>المخزون</th>
                    <th>مميز</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->name_en); ?></td>
                        <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                        <td><?php echo e($product->total_available_stock); ?></td>
                        <td>
                            <?php if($product->featured): ?>
                                <span class="badge bg-success">نعم</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">لا</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.products.show', $product->id)); ?>" class="btn btn-sm btn-info">التفاصيل</a>
                            <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-sm btn-warning">تعديل</a>
                            <a href="<?php echo e(route('admin.products.categories.index', $product->id)); ?>" class="btn btn-sm btn-secondary">الفئات</a>
                            <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من الحذف؟')">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">لا توجد منتجات.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="row mt-4">
            <div class="col-md-12">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/products/index.blade.php ENDPATH**/ ?>