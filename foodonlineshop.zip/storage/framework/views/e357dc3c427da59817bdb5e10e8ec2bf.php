<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-12">
        <h1>Products</h1>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Filter</h5>
                <form action="<?php echo e(route('products.index')); ?>" method="GET">
                    <div class="mb-3">
                        <label for="search" class="form-label">Search</label>
                        <input type="text" class="form-control" id="search" name="search" 
                               value="<?php echo e(request('search')); ?>" placeholder="Search products...">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Categories</label>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="cat_<?php echo e($category->id); ?>" 
                                       name="categories[]" value="<?php echo e($category->id); ?>"
                                       <?php echo e(in_array($category->id, request('categories', [])) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="cat_<?php echo e($category->id); ?>">
                                    <?php echo e($category->name_en); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="featured" name="featured" 
                                   value="1" <?php echo e(request('featured') ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="featured">
                                Featured Only
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-9">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4 mb-3">
                    <div class="card product-card">
                        <?php if($product->primaryImage): ?>
                            <img src="<?php echo e($product->primaryImage->image_url); ?>" class="card-img-top" alt="<?php echo e($product->name_en); ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name_en); ?></h5>
                            <p class="card-text">Price: $<?php echo e(number_format($product->price, 2)); ?></p>
                            <p class="card-text">
                                <?php if($product->isInStock()): ?>
                                    <span class="badge bg-success">In Stock</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Out of Stock</span>
                                <?php endif; ?>
                            </p>
                            <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-sm btn-primary">View</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-md-12">
                    <p>No products found.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="row mt-4">
            <div class="col-md-12">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/products/index.blade.php ENDPATH**/ ?>