<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-12">
        <h1>Delivery Personnel</h1>
        <a href="<?php echo e(route('admin.delivery.create')); ?>" class="btn btn-primary">Add Delivery Person</a>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $deliveryPersons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($delivery->id); ?></td>
                        <td><?php echo e($delivery->first_name); ?> <?php echo e($delivery->last_name); ?></td>
                        <td><?php echo e($delivery->phone); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($delivery->status === 'active' ? 'success' : 'secondary'); ?>">
                                <?php echo e(ucfirst($delivery->status)); ?>

                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.delivery.edit', $delivery->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('admin.delivery.destroy', $delivery->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">No delivery personnel found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="row mt-4">
            <div class="col-md-12">
                <?php echo e($deliveryPersons->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/delivery/index.blade.php ENDPATH**/ ?>