<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>تسجيل البضائع التالفة</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('admin.damaged-goods.index')); ?>" class="btn btn-secondary">العودة</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('admin.damaged-goods.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label class="form-label">المنتج</label>
                    <select name="product_id" id="product_id" class="form-control <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">-- اختر المنتج --</option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>" <?php echo e(old('product_id') == $product->id ? 'selected' : ''); ?>>
                                <?php echo e($product->name_en); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="form-label">الكمية</label>
                    <input 
                        type="number" 
                        name="quantity" 
                        class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('quantity')); ?>"
                        min="1"
                        required
                    >
                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="form-label">المصدر</label>
                    <select name="source" id="source" class="form-control <?php $__errorArgs = ['source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">-- اختر المصدر --</option>
                        <option value="inventory" <?php echo e(old('source') == 'inventory' ? 'selected' : ''); ?>>المخزون (سيتم إنشاء حركة مخزون)</option>
                        <option value="external" <?php echo e(old('source') == 'external' ? 'selected' : ''); ?>>خارجي</option>
                    </select>
                    <?php $__errorArgs = ['source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <small class="form-text text-muted">
                        اختيار "المخزون" سينشئ تلقائيًا سجل حركة مخزون ويخصم من المخزون الحالي.
                    </small>
                </div>

                <div class="mb-3" id="inventory-field" style="display: none;">
                    <label class="form-label">دفعة المخزون</label>
                    <select name="inventory_id" class="form-control <?php $__errorArgs = ['inventory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">-- اختر دفعة المخزون --</option>
                    </select>
                    <?php $__errorArgs = ['inventory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="form-label">السبب</label>
                    <textarea 
                        name="reason" 
                        class="form-control <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        rows="3"
                        required
                    ><?php echo e(old('reason')); ?></textarea>
                    <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">تسجيل البضائع التالفة</button>
                    <a href="<?php echo e(route('admin.damaged-goods.index')); ?>" class="btn btn-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        const productSelect = document.getElementById('product_id');
        const sourceSelect = document.getElementById('source');
        const inventoryField = document.getElementById('inventory-field');
        const inventorySelect = inventoryField.querySelector('select[name="inventory_id"]');
        const getInventoriesUrlTemplate = '<?php echo e(route("admin.damaged-goods.product-inventories", ":product")); ?>';

        let productId = productSelect.value;
        let source = sourceSelect.value;

        function loadInventories() {
            if (source === 'inventory' && productId) {
                const url = getInventoriesUrlTemplate.replace(':product', productId);
                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        inventorySelect.innerHTML = '<option value="">-- Select Inventory Batch --</option>';
                        data.forEach(value => {
                            let optionText = '';
                            if (value.batch_number) {
                                optionText += 'Batch: ' + value.batch_number + ' - ';
                            }
                            optionText += 'Expiry: ' + (value.expiry_date ? value.expiry_date : 'N/A') + ' - Stock: ' + value.stock_quantity;
                            const option = document.createElement('option');
                            option.value = value.id;
                            option.textContent = optionText;
                            inventorySelect.appendChild(option);
                        });
                        inventoryField.style.display = 'block';
                        inventorySelect.required = true;
                    })
                    .catch(error => {
                        inventoryField.style.display = 'none';
                    });
            } else {
                inventoryField.style.display = 'none';
                inventorySelect.required = false;
            }
        }

        productSelect.addEventListener('change', function() {
            productId = this.value;
            loadInventories();
        });

        sourceSelect.addEventListener('change', function() {
            source = this.value;
            loadInventories();
        });

        // Initial load if old values
        loadInventories();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/damaged-goods/create.blade.php ENDPATH**/ ?>