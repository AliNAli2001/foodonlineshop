<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-12">
        <h1>Categories</h1>
    </div>
</div>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-4 mb-3">
            <div class="card">
                <?php if($category->image): ?>
                    <img src="<?php echo e($category->image->image_url); ?>" class="card-img-top" alt="<?php echo e($category->name_en); ?>">
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($category->name_en); ?></h5>
                    <?php if($category->featured): ?>
                        <span class="badge bg-warning">Featured</span>
                    <?php endif; ?>
                    <a href="<?php echo e(route('categories.show', $category->id)); ?>" class="btn btn-sm btn-primary mt-2">View Products</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-md-12">
            <p>No categories available.</p>
        </div>
    <?php endif; ?>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <?php echo e($categories->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/categories/index.blade.php ENDPATH**/ ?>