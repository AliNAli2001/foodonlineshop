<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2><?php echo e($product->name_en); ?> - تفاصيل المنتج</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary">رجوع</a>
            <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-warning">تعديل</a>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>معلومات المنتج</h5>
                </div>
                <div class="card-body">
                    <p><strong>الاسم (بالإنجليزية):</strong> <?php echo e($product->name_en); ?></p>
                    <p><strong>الاسم (بالعربية):</strong> <?php echo e($product->name_ar); ?></p>
                    <p><strong>السعر:</strong> $<?php echo e(number_format($product->price, 2)); ?></p>
                    <p><strong>الحد الأقصى للطلب:</strong> <?php echo e($product->max_order_item ?? 'غير محدود'); ?></p>
                    <p><strong>مميز:</strong> 
                        <span class="badge <?php echo e($product->featured ? 'bg-success' : 'bg-secondary'); ?>">
                            <?php echo e($product->featured ? 'نعم' : 'لا'); ?>

                        </span>
                    </p>
                    <p><strong>الوصف (بالإنجليزية):</strong></p>
                    <p><?php echo e($product->description_en); ?></p>
                    <p><strong>الوصف (بالعربية):</strong></p>
                    <p><?php echo e($product->description_ar); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>معلومات المخزون</h5>
                </div>
                <div class="card-body">
                    <p><strong>إجمالي الكمية:</strong> <?php echo e($product->total_stock); ?></p>
                    <p><strong>الكمية المحجوزة:</strong> <?php echo e($product->total_reserved_stock); ?></p>
                    <p><strong>المتوفر:</strong> <?php echo e($product->total_available_stock); ?></p>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>الفئات</h5>
                </div>
                <div class="card-body">
                    <?php if($product->categories->count() > 0): ?>
                        <div class="row">
                            <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 mb-2">
                                    <span class="badge bg-info"><?php echo e($category->name_ar); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">لا توجد فئات مضافة</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>صور المنتج</h5>
                </div>
                <div class="card-body">
                    <?php if($product->images->count() > 0): ?>
                        <div class="row">
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 mb-3">
                                    <img src="<?php echo e(asset('storage/' . $image->image_url)); ?>" alt="صورة المنتج" style="max-width: 100%; max-height: 200px;">
                                    <?php if($image->is_primary): ?>
                                        <div><span class="badge bg-primary">رئيسية</span></div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">لا توجد صور حتى الآن</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('admin.inventory.product', $product->id)); ?>" class="btn btn-info">عرض المخزون</a>
                <a href="<?php echo e(route('admin.products.categories.index', $product->id)); ?>" class="btn btn-secondary">إدارة الفئات</a>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary">العودة إلى المنتجات</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/products/show.blade.php ENDPATH**/ ?>