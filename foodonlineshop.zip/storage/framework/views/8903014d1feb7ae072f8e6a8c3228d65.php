<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <!-- Header -->
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Product Inventory: <?php echo e($product->name_en); ?></h2>
            <p class="text-muted"><?php echo e($product->name_ar); ?></p>
        </div>
        <div class="col-md-4 text-end">
            <a href="<?php echo e(route('admin.inventory.index')); ?>" class="btn btn-secondary">Back to Inventory List</a>
            <a href="<?php echo e(route('admin.inventory.edit', $product->id)); ?>" class="btn btn-warning">Edit Inventory</a>
        </div>
    </div>

    <!-- Product Summary -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Product Summary</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <strong>Total Stock:</strong>
                    <p><?php echo e($product->total_stock); ?></p>
                </div>
                <div class="col-md-3">
                    <strong>Available:</strong>
                    <p><?php echo e($product->total_available_stock); ?></p>
                </div>
                <div class="col-md-3">
                    <strong>Reserved:</strong>
                    <p><?php echo e($product->total_reserved_stock); ?></p>
                </div>
                <div class="col-md-3">
                    <strong>Minimum Alert:</strong>
                    <p>
                        <?php
                            $minAlert = $inventories->min('minimum_alert_quantity');
                        ?>
                        <?php echo e($minAlert ?? '—'); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- All Inventory Batches -->
    <div class="card mb-4">
        <div class="card-header">
            <h5>Inventory Batches</h5>
        </div>
        <div class="card-body">
            <?php if($inventories->count() > 0): ?>
                <table class="table table-sm table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Batch Number</th>
                            <th>Expiry Date</th>
                            <th>Stock</th>
                            <th>Reserved</th>
                            <th>Available</th>
                            <th>Min Alert</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php if($inventory->isExpired()): ?> table-danger <?php elseif($inventory->isExpiringSoon()): ?> table-warning <?php endif; ?>">
                                <td>
                                    <?php if($inventory->batch_number): ?>
                                        <code><?php echo e($inventory->batch_number); ?></code>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($inventory->expiry_date): ?>
                                        <strong><?php echo e($inventory->expiry_date->format('Y-m-d')); ?></strong>
                                        <?php if($inventory->isExpired()): ?>
                                            <span class="badge bg-danger">Expired</span>
                                        <?php elseif($inventory->isExpiringSoon()): ?>
                                            <span class="badge bg-warning">Expiring Soon (<?php echo e($inventory->getDaysUntilExpiry()); ?> days)</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">No expiry</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($inventory->stock_quantity); ?></td>
                                <td><?php echo e($inventory->reserved_quantity); ?></td>
                                <td><strong><?php echo e($inventory->getAvailableStock()); ?></strong></td>
                                <td><?php echo e($inventory->minimum_alert_quantity); ?></td>
                                <td>
                                    
                                    <?php if($inventory->isBelowMinimum()): ?>
                                        <span class="badge bg-warning">Below Min</span>
                                    <?php elseif($inventory->isExpired()): ?>
                                        <span class="badge bg-danger">Expired</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">OK</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    
                                    <a href="<?php echo e(route('admin.inventory.show', $inventory->id)); ?>" class="btn btn-sm btn-info" title="View Batch">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.inventory.edit', $product->id)); ?>" class="btn btn-sm btn-warning" title="Edit Inventory">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-info mb-0">No inventory records found for this product.</div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Recent Transactions -->
    <div class="card">
        <div class="card-header">
            <h5>Recent Transactions</h5>
        </div>
        <div class="card-body">
            <?php if($transactions->count() > 0): ?>
                <table class="table table-sm align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Type</th>
                            <th>Quantity Change</th>
                            <th>Reserved Change</th>
                            <th>Reason</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="badge bg-info"><?php echo e(ucfirst($transaction->transaction_type)); ?></span></td>
                                <td><?php echo e($transaction->quantity_change > 0 ? '+' : ''); ?><?php echo e($transaction->quantity_change); ?></td>
                                <td><?php echo e($transaction->reserved_change > 0 ? '+' : ''); ?><?php echo e($transaction->reserved_change); ?></td>
                                <td><?php echo e($transaction->reason); ?></td>
                                <td><?php echo e($transaction->created_at->format('Y-m-d H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($transactions->links()); ?>

            <?php else: ?>
                <p class="text-muted mb-0">No transactions yet for this product.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\ecommerce\foodonlineshop\resources\views/admin/inventory/product/create.blade.php ENDPATH**/ ?>